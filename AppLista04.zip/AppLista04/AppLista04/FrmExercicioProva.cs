﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03_Continuacao
{
    public partial class FrmExercicioProva : Form
    {
        public FrmExercicioProva()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void FrmExercicioProva_Load(object sender, EventArgs e)
        {
            float valorNum1 = float.Parse(txtNum1.Text);
            float valorNum2 = float.Parse(txtNum2.Text);
            float valorNum3 = float.Parse(txtNum3.Text);
            float resultado110;
            float resultado220;
            float resultado330;

            resultado110 = (valorNum1 * 0.10f) + valorNum1;
            resultado220 = (valorNum2 * 0.10f) + valorNum2;
            resultado330 = (valorNum3 * 0.10f) + valorNum3;

            lblResultado1.Text = "10% = " + resultado110;
            lblResultado2.Text = "10% = " + resultado220;
            lblResultado3.Text = "10% = " + resultado330;
        }
    }
}
