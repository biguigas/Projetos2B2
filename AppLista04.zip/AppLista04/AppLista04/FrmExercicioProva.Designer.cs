﻿namespace Lista03_Continuacao
{
    partial class FrmExercicioProva
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValor1 = new System.Windows.Forms.Label();
            this.lblValor2 = new System.Windows.Forms.Label();
            this.lblValor3 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.pnlNum1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblNum5 = new System.Windows.Forms.Label();
            this.btnResultado = new System.Windows.Forms.Button();
            this.pnlNum2 = new System.Windows.Forms.Panel();
            this.lblResultado1 = new System.Windows.Forms.Label();
            this.lblResultado2 = new System.Windows.Forms.Label();
            this.lblResultado3 = new System.Windows.Forms.Label();
            this.pnlNum1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblValor1
            // 
            this.lblValor1.AutoSize = true;
            this.lblValor1.Location = new System.Drawing.Point(141, 259);
            this.lblValor1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValor1.Name = "lblValor1";
            this.lblValor1.Size = new System.Drawing.Size(50, 18);
            this.lblValor1.TabIndex = 0;
            this.lblValor1.Text = "Valor1";
            // 
            // lblValor2
            // 
            this.lblValor2.AutoSize = true;
            this.lblValor2.Location = new System.Drawing.Point(141, 389);
            this.lblValor2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValor2.Name = "lblValor2";
            this.lblValor2.Size = new System.Drawing.Size(50, 18);
            this.lblValor2.TabIndex = 1;
            this.lblValor2.Text = "Valor2";
            // 
            // lblValor3
            // 
            this.lblValor3.AutoSize = true;
            this.lblValor3.Location = new System.Drawing.Point(138, 521);
            this.lblValor3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValor3.Name = "lblValor3";
            this.lblValor3.Size = new System.Drawing.Size(50, 18);
            this.lblValor3.TabIndex = 2;
            this.lblValor3.Text = "Valor3";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(93, 295);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(148, 24);
            this.txtNum1.TabIndex = 3;
            this.txtNum1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(93, 426);
            this.txtNum2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(148, 24);
            this.txtNum2.TabIndex = 4;
            this.txtNum2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtNum3
            // 
            this.txtNum3.Location = new System.Drawing.Point(93, 558);
            this.txtNum3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(148, 24);
            this.txtNum3.TabIndex = 5;
            // 
            // pnlNum1
            // 
            this.pnlNum1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pnlNum1.Controls.Add(this.pnlNum2);
            this.pnlNum1.Controls.Add(this.lblNum5);
            this.pnlNum1.Controls.Add(this.label1);
            this.pnlNum1.Location = new System.Drawing.Point(-12, -7);
            this.pnlNum1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlNum1.Name = "pnlNum1";
            this.pnlNum1.Size = new System.Drawing.Size(1515, 210);
            this.pnlNum1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(566, 130);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // lblNum5
            // 
            this.lblNum5.AutoSize = true;
            this.lblNum5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblNum5.Font = new System.Drawing.Font("Showcard Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblNum5.Location = new System.Drawing.Point(90, 127);
            this.lblNum5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum5.Name = "lblNum5";
            this.lblNum5.Size = new System.Drawing.Size(230, 60);
            this.lblNum5.TabIndex = 7;
            this.lblNum5.Text = "Revisão";
            // 
            // btnResultado
            // 
            this.btnResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResultado.Location = new System.Drawing.Point(557, 417);
            this.btnResultado.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnResultado.Name = "btnResultado";
            this.btnResultado.Size = new System.Drawing.Size(171, 75);
            this.btnResultado.TabIndex = 7;
            this.btnResultado.Text = "Resultado";
            this.btnResultado.UseVisualStyleBackColor = true;
            // 
            // pnlNum2
            // 
            this.pnlNum2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pnlNum2.Location = new System.Drawing.Point(1204, 206);
            this.pnlNum2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlNum2.Name = "pnlNum2";
            this.pnlNum2.Size = new System.Drawing.Size(336, 618);
            this.pnlNum2.TabIndex = 8;
            // 
            // lblResultado1
            // 
            this.lblResultado1.AutoSize = true;
            this.lblResultado1.Location = new System.Drawing.Point(969, 298);
            this.lblResultado1.Name = "lblResultado1";
            this.lblResultado1.Size = new System.Drawing.Size(147, 18);
            this.lblResultado1.TabIndex = 8;
            this.lblResultado1.Text = "O valor1 com 10% é ";
            // 
            // lblResultado2
            // 
            this.lblResultado2.AutoSize = true;
            this.lblResultado2.Location = new System.Drawing.Point(969, 432);
            this.lblResultado2.Name = "lblResultado2";
            this.lblResultado2.Size = new System.Drawing.Size(147, 18);
            this.lblResultado2.TabIndex = 9;
            this.lblResultado2.Text = "O valor2 com 10% é ";
            // 
            // lblResultado3
            // 
            this.lblResultado3.AutoSize = true;
            this.lblResultado3.Location = new System.Drawing.Point(969, 558);
            this.lblResultado3.Name = "lblResultado3";
            this.lblResultado3.Size = new System.Drawing.Size(147, 18);
            this.lblResultado3.TabIndex = 10;
            this.lblResultado3.Text = "O valor3 com 10% é ";
            // 
            // FrmExercicioProva
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1470, 807);
            this.Controls.Add(this.lblResultado3);
            this.Controls.Add(this.lblResultado2);
            this.Controls.Add(this.lblResultado1);
            this.Controls.Add(this.btnResultado);
            this.Controls.Add(this.pnlNum1);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblValor3);
            this.Controls.Add(this.lblValor2);
            this.Controls.Add(this.lblValor1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmExercicioProva";
            this.Text = "QUESTAO_PROVA";
            this.Load += new System.EventHandler(this.FrmExercicioProva_Load);
            this.pnlNum1.ResumeLayout(false);
            this.pnlNum1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblValor1;
        private System.Windows.Forms.Label lblValor2;
        private System.Windows.Forms.Label lblValor3;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Panel pnlNum1;
        private System.Windows.Forms.Label lblNum5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlNum2;
        private System.Windows.Forms.Button btnResultado;
        private System.Windows.Forms.Label lblResultado1;
        private System.Windows.Forms.Label lblResultado2;
        private System.Windows.Forms.Label lblResultado3;
    }
}