﻿namespace AppLista03
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblVlrPagar = new System.Windows.Forms.Label();
            this.lblVlrLitro = new System.Windows.Forms.Label();
            this.txtVlrLitro = new System.Windows.Forms.TextBox();
            this.txtVlrPagar = new System.Windows.Forms.TextBox();
            this.btnRes = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblVlrPagar
            // 
            this.lblVlrPagar.AutoSize = true;
            this.lblVlrPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrPagar.Location = new System.Drawing.Point(330, 64);
            this.lblVlrPagar.Name = "lblVlrPagar";
            this.lblVlrPagar.Size = new System.Drawing.Size(108, 18);
            this.lblVlrPagar.TabIndex = 0;
            this.lblVlrPagar.Text = "Valor a pagar";
            this.lblVlrPagar.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblVlrLitro
            // 
            this.lblVlrLitro.AutoSize = true;
            this.lblVlrLitro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrLitro.Location = new System.Drawing.Point(319, 126);
            this.lblVlrLitro.Name = "lblVlrLitro";
            this.lblVlrLitro.Size = new System.Drawing.Size(149, 18);
            this.lblVlrLitro.TabIndex = 1;
            this.lblVlrLitro.Text = "Valor litro gasolina";
            this.lblVlrLitro.Click += new System.EventHandler(this.lblNum02_Click);
            // 
            // txtVlrLitro
            // 
            this.txtVlrLitro.Location = new System.Drawing.Point(333, 147);
            this.txtVlrLitro.Name = "txtVlrLitro";
            this.txtVlrLitro.Size = new System.Drawing.Size(113, 20);
            this.txtVlrLitro.TabIndex = 2;
            this.txtVlrLitro.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtVlrPagar
            // 
            this.txtVlrPagar.Location = new System.Drawing.Point(333, 85);
            this.txtVlrPagar.Name = "txtVlrPagar";
            this.txtVlrPagar.Size = new System.Drawing.Size(105, 20);
            this.txtVlrPagar.TabIndex = 3;
            // 
            // btnRes
            // 
            this.btnRes.Location = new System.Drawing.Point(333, 227);
            this.btnRes.Name = "btnRes";
            this.btnRes.Size = new System.Drawing.Size(122, 52);
            this.btnRes.TabIndex = 4;
            this.btnRes.Text = "Calcular";
            this.btnRes.UseVisualStyleBackColor = true;
            this.btnRes.Click += new System.EventHandler(this.btnRes_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Lembra de deslogar o PC";
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnRes);
            this.Controls.Add(this.txtVlrPagar);
            this.Controls.Add(this.txtVlrLitro);
            this.Controls.Add(this.lblVlrLitro);
            this.Controls.Add(this.lblVlrPagar);
            this.Name = "FrmExercicio02";
            this.Text = "FrmExercicio02";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblVlrPagar;
        private System.Windows.Forms.Label lblVlrLitro;
        private System.Windows.Forms.TextBox txtVlrLitro;
        private System.Windows.Forms.TextBox txtVlrPagar;
        private System.Windows.Forms.Button btnRes;
        private System.Windows.Forms.Label label1;
    }
}