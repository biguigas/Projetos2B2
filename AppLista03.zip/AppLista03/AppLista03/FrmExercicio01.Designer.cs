﻿namespace AppLista03
{
    partial class frmEx1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNum1 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblRsoma = new System.Windows.Forms.Label();
            this.lblRmedia = new System.Windows.Forms.Label();
            this.lblRPorcentagem = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum1.Location = new System.Drawing.Point(95, 139);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(36, 16);
            this.lblNum1.TabIndex = 0;
            this.lblNum1.Text = "Num1";
            this.lblNum1.Click += new System.EventHandler(this.lblNum1_Click);
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(60, 155);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(100, 20);
            this.txtNum1.TabIndex = 1;
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum2.Location = new System.Drawing.Point(245, 139);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(37, 16);
            this.lblNum2.TabIndex = 2;
            this.lblNum2.Text = "Num2";
            // 
            // lblNum3
            // 
            this.lblNum3.AutoSize = true;
            this.lblNum3.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum3.Location = new System.Drawing.Point(390, 139);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(37, 16);
            this.lblNum3.TabIndex = 3;
            this.lblNum3.Text = "Num3";
            this.lblNum3.Click += new System.EventHandler(this.lblNum3_Click);
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(214, 155);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(100, 20);
            this.txtNum2.TabIndex = 4;
            // 
            // txtNum3
            // 
            this.txtNum3.Location = new System.Drawing.Point(352, 155);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(107, 20);
            this.txtNum3.TabIndex = 5;
            // 
            // btnSoma
            // 
            this.btnSoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoma.Location = new System.Drawing.Point(69, 221);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(78, 29);
            this.btnSoma.TabIndex = 6;
            this.btnSoma.Text = "a)Soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedia.Location = new System.Drawing.Point(223, 221);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(81, 28);
            this.btnMedia.TabIndex = 7;
            this.btnMedia.Text = "b)Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPorcentagem.Location = new System.Drawing.Point(352, 220);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(109, 29);
            this.btnPorcentagem.TabIndex = 8;
            this.btnPorcentagem.Text = "c)Porcentagem";
            this.btnPorcentagem.UseVisualStyleBackColor = true;
            this.btnPorcentagem.Click += new System.EventHandler(this.btnPorcentagem_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(16, 20);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(144, 20);
            this.lblNome.TabIndex = 9;
            this.lblNome.Text = "Exercício lista 03";
            this.lblNome.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblRsoma
            // 
            this.lblRsoma.AutoSize = true;
            this.lblRsoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRsoma.Location = new System.Drawing.Point(239, 317);
            this.lblRsoma.Name = "lblRsoma";
            this.lblRsoma.Size = new System.Drawing.Size(122, 16);
            this.lblRsoma.TabIndex = 10;
            this.lblRsoma.Text = "Resultado Soma";
            this.lblRsoma.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblRmedia
            // 
            this.lblRmedia.AutoSize = true;
            this.lblRmedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRmedia.Location = new System.Drawing.Point(239, 342);
            this.lblRmedia.Name = "lblRmedia";
            this.lblRmedia.Size = new System.Drawing.Size(125, 16);
            this.lblRmedia.TabIndex = 11;
            this.lblRmedia.Text = "Resultado Media";
            // 
            // lblRPorcentagem
            // 
            this.lblRPorcentagem.AutoSize = true;
            this.lblRPorcentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRPorcentagem.Location = new System.Drawing.Point(239, 366);
            this.lblRPorcentagem.Name = "lblRPorcentagem";
            this.lblRPorcentagem.Size = new System.Drawing.Size(174, 16);
            this.lblRPorcentagem.TabIndex = 12;
            this.lblRPorcentagem.Text = "Resultado Porcentagem";
            // 
            // frmEx1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblRPorcentagem);
            this.Controls.Add(this.lblRmedia);
            this.Controls.Add(this.lblRsoma);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum1);
            this.Name = "frmEx1";
            this.Text = "Exercício lista 03";
            this.Load += new System.EventHandler(this.frmEx1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblRsoma;
        private System.Windows.Forms.Label lblRmedia;
        private System.Windows.Forms.Label lblRPorcentagem;
    }
}

