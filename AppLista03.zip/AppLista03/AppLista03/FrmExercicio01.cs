﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class frmEx1 : Form
    {
        public frmEx1()
        {
            InitializeComponent();
        }

        private void lblNum3_Click(object sender, EventArgs e)
        {

        }

        private void lblNum1_Click(object sender, EventArgs e)
        {

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float media;

            media = (Num1 + Num2 + Num3) / 3;
            lblRmedia.Text = "Media igual a " + media;
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float soma;

            soma = Num1 + Num3;

            lblRsoma.Text = "Soma igual a" + soma;
        }


        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float total, porcNum1, porcNum2, porcNum3;

            total = Num1 + Num2 + Num3; //100%
            porcNum1 = Num1 / total;
            porcNum2 = Num2 / total;
            porcNum3 = Num3 / total;

            lblRPorcentagem.Text = "Num1 é" + porcNum1 + "% - " + "Num2 é" + porcNum2 + "% - " + "Num3 é" + porcNum3 + "%.";



        }


        private void frmEx1_Load(object sender, EventArgs e)
        {

        }
    }

}
